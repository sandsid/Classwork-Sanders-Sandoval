﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab2
{
    class PurchasedItem
    {
        private int item;
        private int size;
        private int quantity;
        private static string format;
        private static decimal[,] itemCost;


        static PurchasedItem() 
        { 
            format = "{0, 2}  {1, 1} {2, -15} {3, 10:C}"; 
            itemCost = new decimal[4, 3] 
            { 
                { 2.50M, 3.00M, 3.50M }, 
                { 0.99M, 1.29M, 1.49M }, 
                { 1.29M, 1.40M, 1.60M }, 
                { 0.00M, 0.00M, 0.00M } 
            }; 
        }

        public decimal Cost()
        {



        }

    }
}
